from ._npyio_impl import (
    __doc__, DataSource, NpzFile
)
